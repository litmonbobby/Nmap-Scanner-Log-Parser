import argparse
import subprocess
import re
from datetime import datetime

def run_nmap(target):
    print(f"[+] Scanning {target}...")
    result = subprocess.run(["nmap", "-sS", "-T4", "-Pn", target], capture_output=True, text=True)
    return result.stdout

def parse_output(output):
    log = []
    for line in output.splitlines():
        if re.match(r"^\d+/tcp", line):
            port_info = line.strip().split()
            port, state, service = port_info[0], port_info[1], port_info[2]
            tag = "[+]" if int(port.split("/")[0]) not in [23, 445] else "[!] Potential risk:"
            log.append(f"{tag} {port} ({service})")
    return log

def save_log(entries, target):
    filename = f"scan_{target.replace('.', '_')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    with open(filename, "w") as f:
        for entry in entries:
            f.write(entry + "\n")
    print(f"[+] Log saved to {filename}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Fast Nmap Scanner and Log Parser")
    parser.add_argument("--target", required=True, help="Target IP address")
    args = parser.parse_args()

    output = run_nmap(args.target)
    results = parse_output(output)
    for line in results:
        print(line)
    save_log(results, args.target)
