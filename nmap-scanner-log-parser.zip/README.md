# Nmap Scanner & Log Parser

A Python CLI tool to run fast Nmap scans, parse the output for useful information (open ports, services, OS), and highlight high-risk ports.

## Features
- Runs fast Nmap scans using subprocess
- Parses output for:
  - Open ports
  - Detected services
  - OS information (if available)
- Colorized terminal output
- Saves results to log file

## Skills Demonstrated
- Python scripting
- Subprocess handling
- Regex and file parsing
- CLI development
- Basic network scanning concepts

## Example Usage
```bash
$ python scanner.py --target 192.168.1.10
```

## Example Output
```text
[+] Open Port: 22/tcp (ssh)
[+] Open Port: 80/tcp (http)
[!] Potential risk: Port 23/tcp (telnet)
```

## Setup
```bash
git clone https://github.com/your-username/nmap-scanner-log-parser.git
cd nmap-scanner-log-parser
python scanner.py --help
```

**Note:** Requires Nmap to be installed.

---

**Author:** Bobby Litmon  
**Contact:** litmonbobby@gmail.com
